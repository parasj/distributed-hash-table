# distributed-hash-table
An implementation of a distributed key-value store like Amazon's DynamoDB

## Running instructions
1. cd into GTStore and run make
2. run ./bench.sh