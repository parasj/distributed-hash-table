package clock;

/**
 * GTStore
 */
public enum VectorDelta {
    LESS_THAN, EQUAL, GREATER_THAN, CONFLICT;
}